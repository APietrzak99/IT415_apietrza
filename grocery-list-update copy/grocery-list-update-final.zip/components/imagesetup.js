const products = {
    product_images: {
        Bread: require('../assets/products/bread.jpg'),
        Cereal: require('../assets/products/cereal.png'),
        Doritos: require('../assets/products/doritos.jpg'),
        Milk: require('../assets/products/milk.jpg'),
        Salami: require('../assets/products/salami.jpg'),
        placeholder: require('../assets/products/placeholder.png'),
    },
};

export default products;

